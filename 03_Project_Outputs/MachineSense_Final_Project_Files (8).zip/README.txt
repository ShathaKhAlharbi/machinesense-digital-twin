MachineSense Final Project Files

Selected model: Random Forest

Risk-state thresholds:
- Normal: probability < 0.19
- Warning: 0.19 <= probability < 0.37
- High Risk: probability >= 0.37

Main dashboard folder:
01_dashboard_files

Final model:
01_dashboard_files/FINAL_random_forest_model.joblib

Dashboard prediction file:
01_dashboard_files/dashboard_predictions.csv

The model expects 14 preprocessed features.
Use the exact order stored in feature_names.csv.

Do not use these columns as model features:
- machine_id
- timestamp
- failure_within_24h
- failure_type
- rul_hours
- estimated_repair_cost

Use MachineSense_Processed_Data_with_Metadata.zip
for processed data and preprocessing information.